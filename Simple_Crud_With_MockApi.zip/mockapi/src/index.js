import ReactDOM  from 'react-dom/client';
import App from './App';




const AppRoot = ReactDOM.createRoot(document.getElementById("root"));


AppRoot.render(<App/>)